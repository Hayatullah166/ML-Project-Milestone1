# Energy Consumption Prediction with MLOps
# Project structure for Milestone 1

data/
├── raw/                    # Original datasets
├── processed/              # Cleaned and engineered features
└── reference/              # Reference datasets for drift detection

models/
├── trained/                # Saved model artifacts
└── scalers/                # Feature scalers

src/
├── data/                   # Data pipeline modules
│   ├── __init__.py
│   ├── loader.py          # Data loading utilities
│   ├── preprocessor.py    # Data cleaning and preprocessing
│   └── feature_engineering.py
├── models/                 # Model development
│   ├── __init__.py
│   ├── baseline.py        # Baseline models
│   ├── trainer.py         # Model training pipeline
│   └── evaluator.py       # Model evaluation
├── api/                    # FastAPI application
│   ├── __init__.py
│   ├── main.py           # FastAPI app
│   └── schemas.py        # Pydantic models
├── mlops/                  # MLOps components
│   ├── __init__.py
│   ├── drift_detector.py  # EvidentlyAI integration
│   ├── retraining.py      # Automated retraining
│   └── monitoring.py      # Performance monitoring
└── utils/                  # Utility functions
    ├── __init__.py
    ├── config.py          # Configuration management
    └── helpers.py         # Helper functions

notebooks/                  # Jupyter notebooks for exploration
├── data_exploration.ipynb
├── model_development.ipynb
└── drift_analysis.ipynb

tests/                      # Unit tests
├── __init__.py
├── test_data_pipeline.py
├── test_models.py
└── test_api.py

scripts/                    # Standalone scripts
├── download_data.py
├── train_model.py
└── run_drift_check.py

config/                     # Configuration files
├── config.yaml
└── model_config.yaml

mlruns/                     # MLflow tracking (auto-created)
reports/                    # EvidentlyAI reports
logs/                       # Application logs

README.md
requirements.txt
.env.example

## Milestone 2: LLM Assistant and Dashboard (in progress)

- **Goal:** Add an AI-powered Q&A assistant and interactive dashboard so users can:
  - Query energy trends and get natural-language explanations for load changes and drift
  - Ask questions about consumption, model performance, and recent anomalies
  - Access live prediction and monitoring with a user-friendly dashboard
- **LLM integration:**
  - OpenAI API (e.g. GPT-3.5/4, requires API key in .env) or Llama-API (open-source alternative)
  - Helper API module will route questions & context to LLM, returning answers for dashboard/UI
- **Dashboard:**
  - Streamlit app displays predictions, drift/alert status, and includes a chat interface for LLM Q&A
  - Integrates with backend to access up-to-date data and call LLM assistant endpoints
- **Configuration:**
  - Store sensitive keys (like OPENAI_API_KEY) in `.env` and load using python-dotenv

## Running the Dashboard & API

1. **Start your FastAPI backend:**
   ```bash
   uvicorn src.api.main:app --reload
   # Or: python -m uvicorn src.api.main:app --reload
   ```
2. **(Optional) Set API_HOST environment variable if backend not on localhost:8000:**
   ```bash
   export API_HOST="http://localhost:8000"
   # Windows:
   set API_HOST=http://localhost:8000
   # Or add to your .env file (not required for localhost)
   ```
3. **Start Streamlit dashboard:**
   ```bash
   streamlit run src/dashboard/main.py
   ```
4. **Use features:**
   - Fetch real predictions (Model tab)
   - Trigger retraining or check drift (Drift/Health tab)
   - Ask questions in Assistant tab (requires correct OpenAI API key in .env)
   - In the header, you can see API health and currently active model. Use the dropdown to activate a different trained model.

**Troubleshooting**
- If you see Streamlit secret errors, ignore them unless using secrets.toml. The dashboard works with environment variables by default.
- To enable LLM answers, set `OPENAI_API_KEY` in a `.env` file (never commit your secret!), or set as OS env variable.
- If API is offline, dashboard will revert to demo data for plots or display error messages.
- See comments/documentation for customization or further expansion.

### Using Groq (free-tier) for the LLM Assistant
1. Create an account at groq.com and generate an API key.
2. Set your key as an environment variable (Windows PowerShell):
   ```powershell
   setx GROQ_API_KEY "gsk_your_key_here"
   ```
   Then restart the terminal.
3. Default config is set to Groq in `config/config.yaml`:
   ```yaml
   llm:
     provider: groq
     api_url: https://api.groq.com/openai/v1/chat/completions
     model: llama-3.1-8b-instant
   ```
4. Start your API and Streamlit. In the dashboard Assistant tab, the backend will use Groq automatically. To use OpenAI instead, change `llm.provider` to `openai` and set `OPENAI_API_KEY`.

### Train on PJM CSV
1. Place your file at `data/raw/PJM_Load_hourly.csv` (columns: `Datetime`, `PJM_Load_MW`).
2. Ensure `model.target_column: PJM_Load_MW` in `config/config.yaml` (already set).
3. Train:
```bash
python scripts/train_model.py --use-real-data --data-file data/raw/PJM_Load_hourly.csv
```
4. Restart the API and use the dashboard.
