# Model Evaluation Report

Generated on: 2025-10-31 19:13:49

## Model Comparison

  Model         MAE       RMSE       R�  MAPE (%)  SMAPE (%)  Directional Accuracy (%)  Persistence Skill (%)
xgboost 1543.687834 2198.52167 0.869129   5.00587   5.005812                 82.863241              69.183376


## Detailed Metrics

### xgboost

- **MAE**: 1543.6878
- **RMSE**: 2198.5217
- **R�**: 0.8691
- **MAPE**: 5.01%
- **SMAPE**: 5.01%
- **Directional Accuracy**: 82.86%
- **Persistence Skill**: 69.18%
- **Max Error**: 10387.0352
- **Mean Error**: 233.1261
- **Std Error**: 2186.1267
- **Residual Autocorr**: 0.9484


## Recommendation

**Best Model**: xgboost
- MAE: 1543.6878
- RMSE: 2198.5217
- R�: 0.8691