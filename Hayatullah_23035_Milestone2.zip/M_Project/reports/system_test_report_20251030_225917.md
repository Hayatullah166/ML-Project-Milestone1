# Energy Consumption Prediction System - Test Report

Generated on: 2025-10-30 22:59:17

## Overall Results

- **Overall Success**: FAIL
- **Tests Passed**: 1
- **Tests Failed**: 5
- **Success Rate**: 16.7%

## Detailed Test Results

### Data Pipeline

**Status**: FAIL

**Errors**:
- ['PJM_Load_MW']

### Model Training

**Status**: FAIL

**Errors**:
- ['PJM_Load_MW']

### Model Evaluation

**Status**: FAIL

**Errors**:
- No trained models available

### Drift Detection

**Status**: FAIL

**Errors**:
- ['PJM_Load_MW']

### Retraining Pipeline

**Status**: PASS

- **Retraining Results**: {'success': False, 'new_model_name': None, 'metrics': {}, 'training_time': 0.004078, 'message': 'Retraining failed: No data available for retraining', 'timestamp': '2025-10-30T22:59:17.166855'}
- **Retraining Check**: {'retraining_needed': True, 'reasons': ['Data drift detected (score: 1.000)', 'Performance degraded (MAE increase: 0.135)'], 'drift_check': {'drift_detected': np.True_, 'drift_score': np.float64(1.0), 'drift_details': {'overall_drift_score': np.float64(1.0), 'feature_drifts': {'month': {'ks_statistic': 0.64375, 'ks_pvalue': 0.0, 'mw_statistic': 7905571.0, 'mw_pvalue': 4.603119519278147e-162, 'mean_difference': 0.8707592033101998, 'drift_detected': True}, 'year': {'ks_statistic': 1.0, 'ks_pvalue': 0.0, 'mw_statistic': 0.0, 'mw_pvalue': 0.0, 'mean_difference': 23.478627351431612, 'drift_detected': True}, 'day_of_week': {'ks_statistic': 0.017774140599645438, 'ks_pvalue': 0.919941434480274, 'mw_statistic': 16203864.0, 'mw_pvalue': 0.5424495321573285, 'mean_difference': 0.01980424412586319, 'drift_detected': False}, 'day_sin': {'ks_statistic': 0.01777414059964555, 'ks_pvalue': 0.9199414344802705, 'mw_statistic': 15816801.0, 'mw_pvalue': 0.48831176391061615, 'mean_difference': 0.02440958038355761, 'drift_detected': False}, 'hour_sin': {'ks_statistic': 0.0025953329006166426, 'ks_pvalue': 1.0, 'mw_statistic': 16056706.0, 'mw_pvalue': 0.9099807917116483, 'mean_difference': 0.0041906800175234675, 'drift_detected': False}, 'hour_cos': {'ks_statistic': 0.0040371845120702465, 'ks_pvalue': 1.0, 'mw_statistic': 16092787.0, 'mw_pvalue': 0.8155053629621516, 'mean_difference': 0.00734818927464944, 'drift_detected': False}, 'is_work_hours': {'ks_statistic': 0.0025953329006166426, 'ks_pvalue': 1.0, 'mw_statistic': 15981215.5, 'mw_pvalue': 0.8688611352607559, 'mean_difference': 0.005360553477727035, 'drift_detected': False}, 'day_cos': {'ks_statistic': 0.019857952417804622, 'ks_pvalue': 0.8409414243176594, 'mw_statistic': 15647273.0, 'mw_pvalue': 0.20648027786429046, 'mean_difference': 0.0342956371792708, 'drift_detected': False}, 'target': {'ks_statistic': 1.0, 'ks_pvalue': 0.0, 'mw_statistic': 32045600.0, 'mw_pvalue': 0.0, 'mean_difference': 5.198412446641543, 'drift_detected': True}, 'quarter': {'ks_statistic': 0.4674811830641336, 'ks_pvalue': 1.2793206640063349e-190, 'mw_statistic': 6576415.5, 'mw_pvalue': 2.6310875979247768e-232, 'mean_difference': 1.0420570324975105, 'drift_detected': True}, 'is_weekend': {'ks_statistic': 0.002083811818159198, 'ks_pvalue': 1.0, 'mw_statistic': 15989411.5, 'mw_pvalue': 0.8871266457984943, 'mean_difference': 0.0046085859016913215, 'drift_detected': False}, 'is_night': {'ks_statistic': 0.004325554834361034, 'ks_pvalue': 1.0, 'mw_statistic': 16092107.5, 'mw_pvalue': 0.783130346305134, 'mean_difference': 0.008935418372809823, 'drift_detected': False}, 'hour': {'ks_statistic': 0.004167124347804391, 'ks_pvalue': 1.0, 'mw_statistic': 15967650.5, 'mw_pvalue': 0.8541839986670365, 'mean_difference': 0.005967517125580275, 'drift_detected': False}}, 'drift_detected_features': 4, 'total_features': 13}, 'recommendation': 'High drift detected (30.8% of features). Immediate model retraining recommended.', 'timestamp': '2025-10-30T22:59:17.164642', 'report_path': 'reports\\drift_report_20251030_225917.json'}, 'performance_check': {'performance_degraded': True, 'current_mae': 1543.6878343535632, 'recent_mae': 1752.1257926308713, 'mae_increase': 0.13502597716888393, 'threshold': 0.05}, 'timestamp': '2025-10-30T22:59:16.502781'}

### End To End Workflow

**Status**: FAIL

**Errors**:
- ['PJM_Load_MW']
