"""
LLM Assistant module for energy Q&A.
"""
import os
import requests
from src.utils.config import config

# ----------------- OpenAI -----------------

def get_openai_api_headers():
    key = config.get_llm_api_key()
    if not key:
        raise RuntimeError("OPENAI_API_KEY not set in environment or .env")
    return {
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json"
    }

def call_openai_chat(question, context=None, model=None):
    api_url = config.get_llm_api_url() or "https://api.openai.com/v1/chat/completions"
    headers = get_openai_api_headers()
    if model is None:
        model = config.get('llm.model', 'gpt-3.5-turbo')
    messages = [{"role": "system", "content": "You are an expert assistant for energy forecasting analytics."},
                {"role": "user", "content": question}]
    payload = {"model": model, "messages": messages}
    try:
        response = requests.post(api_url, json=payload, headers=headers, timeout=20)
        response.raise_for_status()
        data = response.json()
        answer = data.get("choices", [{}])[0].get("message", {}).get("content", "[No answer returned]")
        return {"answer": answer, "used_model": model, "details": {"api_time": response.elapsed.total_seconds(), "api_url": api_url, "prompt_length": len(str(messages)), "openai_response": data}}
    except Exception as ex:
        return {"answer": f"[LLM Error] {ex}", "used_model": model, "details": {"api_url": api_url, "error": str(ex)}}

# ----------------- Groq -----------------

def get_groq_api_headers():
    key = config.get_groq_api_key()
    if not key:
        raise RuntimeError("GROQ_API_KEY not set in environment or .env")
    return {
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json"
    }

def call_groq_chat(question, context=None, model=None):
    # Groq uses an OpenAI-compatible chat completions endpoint
    api_url = config.get('llm.api_url', 'https://api.groq.com/openai/v1/chat/completions')
    headers = get_groq_api_headers()
    if model is None:
        model = config.get('llm.model', 'llama-3.1-8b-instant')
    messages = [{"role": "system", "content": "You are an expert assistant for energy forecasting analytics."},
                {"role": "user", "content": question}]
    payload = {"model": model, "messages": messages}
    try:
        response = requests.post(api_url, json=payload, headers=headers, timeout=20)
        response.raise_for_status()
        data = response.json()
        answer = data.get("choices", [{}])[0].get("message", {}).get("content", "[No answer returned]")
        return {"answer": answer, "used_model": model, "details": {"api_time": response.elapsed.total_seconds(), "api_url": api_url, "prompt_length": len(str(messages)), "openai_response": data}}
    except Exception as ex:
        return {"answer": f"[LLM Error] {ex}", "used_model": model, "details": {"api_url": api_url, "error": str(ex)}}

# ----------------- Dispatcher -----------------

def call_llm(provider: str, question: str, context=None, model=None):
    provider = (provider or '').lower()
    if provider == 'groq':
        return call_groq_chat(question, context=context, model=model)
    # default to openai
    return call_openai_chat(question, context=context, model=model)
