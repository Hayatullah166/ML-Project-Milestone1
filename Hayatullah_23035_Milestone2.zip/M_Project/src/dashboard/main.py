
import streamlit as st
import requests
import os
import json
from datetime import datetime
import subprocess
from pathlib import Path
import glob
from dotenv import load_dotenv
load_dotenv()

st.set_page_config(page_title="Energy MLOps Dashboard", layout="wide")

API_HOST = os.getenv("API_HOST")
if not API_HOST:
    try:
        API_HOST = st.secrets["api_host"]
    except Exception:
        API_HOST = None
API_HOST = (API_HOST or "http://localhost:8000").strip()

def call_api(route, method="get", **kwargs):
    url = f"{API_HOST}{route}"
    try:
        if method.lower() == "post":
            resp = requests.post(url, **kwargs, timeout=20)
        else:
            resp = requests.get(url, **kwargs, timeout=20)
        resp.raise_for_status()
        return resp.json()
    except Exception as ex:
        return {"error": str(ex)}

def load_drift_dashboard():
    dashboard_path = os.path.join("reports", "dashboard", "dashboard.json")
    try:
        with open(dashboard_path, "r") as f:
            return json.load(f)
    except Exception:
        return None

st.title("⚡ Energy Forecast & MLOps Assistant Dashboard")
tabs = st.tabs(["🌤️ Forecast & Model", "🛡️ Drift/Health", "🤖 Assistant Chat", "📄 Reports"])

with st.container():
    cols = st.columns([1, 2])
    with cols[0]:
        health = call_api("/")
        status = health.get("status") if isinstance(health, dict) else None
        status_chip = "🟢" if status == "healthy" else "🔴"
        st.markdown(f"**API Health:** {status_chip} {status or 'unknown'} | Host: `{API_HOST}`")
    with cols[1]:
        models_info = call_api("/models")
        if isinstance(models_info, dict) and "models" in models_info:
            names = [m.get("name") for m in models_info["models"]]
            active = models_info.get("active_model")
            choice = st.selectbox("Active model", options=names or ["none"], index=(names.index(active) if active in (names or []) else 0))
            if st.button("Activate Selected Model"):
                resp = call_api(f"/models/{choice}/activate", method="post")
                if isinstance(resp, dict) and resp.get("message"):
                    st.success(resp["message"])
                    st.session_state["refresh_prediction"] = True
                else:
                    st.error(f"Failed to activate model: {resp}")
        else:
            st.caption("Model registry unavailable or API offline.")

with tabs[0]:
    st.header("Consumption Forecast – Live if Available")
    st.markdown("Attempts live predictions from the backend; falls back to demo plot.")

    auto_live_default = True
    if st.session_state.get("refresh_prediction"):
        auto_live_default = True
        st.session_state["refresh_prediction"] = False
    auto_live = st.checkbox("Attempt live API on load", value=auto_live_default)

    import numpy as np
    import pandas as pd
    now = datetime.now()
    hours_hist = pd.date_range(end=now, periods=168, freq="h")
    y_real = 2 + 0.5 * np.sin(np.arange(168) / 24 * 2 * np.pi) + np.random.normal(0,0.1,168)

    def build_demo_history():
        hist = []
        for i, ts in enumerate(hours_hist):
            hist.append({
                "datetime": ts.isoformat(),
                "Global_active_power": float(y_real[i]),
                "Global_reactive_power": float(np.random.uniform(0, 0.5)),
                "Voltage": float(np.random.normal(240, 5)),
                "Global_intensity": float(np.random.uniform(3, 5)),
                "Sub_metering_1": float(np.random.uniform(0, 1)),
                "Sub_metering_2": float(np.random.uniform(0, 1)),
                "Sub_metering_3": float(np.random.uniform(0, 1))
            })
        return hist

    used_live = False
    live_preds = None
    if auto_live:
        try:
            payload = {"historical_data": build_demo_history(), "horizon": 24}
            resp = call_api("/predict", method="post", json=payload)
            if isinstance(resp, dict) and "predictions" in resp:
                times = [pd.to_datetime(p["datetime"]) for p in resp["predictions"]]
                preds = [float(p["predicted_consumption"]) for p in resp["predictions"]]
                live_preds = pd.Series(preds, index=times)
                used_live = True
                st.success("Live predictions fetched from backend.")
            else:
                st.info("Backend response did not include predictions; using demo mode.")
        except Exception as ex:
            st.info(f"Live fetch failed ({ex}); using demo mode.")

    if not used_live:
        future_times = pd.date_range(start=now + pd.Timedelta(hours=1), periods=24, freq="h")
        demo_pred = (2 + 0.5 * np.sin(np.arange(168, 168+24) / 24 * 2 * np.pi)).astype(float) + np.random.normal(0, 0.07, 24)
        live_preds = pd.Series(demo_pred, index=future_times)

    st.subheader("Forecast Plot")
    hist_df = pd.DataFrame({"value": y_real, "series": "Actual"}, index=hours_hist).reset_index().rename(columns={"index": "time"})
    pred_df = pd.DataFrame({"value": live_preds.values, "series": "Prediction"}, index=live_preds.index).reset_index().rename(columns={"index": "time"})

    import altair as alt
    base = alt.Chart(pd.concat([hist_df, pred_df], axis=0)).encode(
        x=alt.X('time:T', title='Time'),
        y=alt.Y('value:Q', title='Energy'),
        color=alt.Color('series:N', scale=alt.Scale(scheme='category10'))
    )
    lines = base.mark_line()
    now_rule = alt.Chart(pd.DataFrame({"time": [now]})).mark_rule(color='red').encode(x='time:T')
    st.altair_chart(lines + now_rule, use_container_width=True)

    st.subheader("Residuals (Backtest demo)")
    last24_idx = hours_hist[-24:]
    if len(live_preds.index) >= 24:
        pseudo_actuals = pd.Series(y_real[-24:], index=last24_idx)
        aligned_preds = pd.Series(live_preds.values[:24], index=last24_idx)
        residuals = pseudo_actuals - aligned_preds
        res_df = pd.DataFrame({"time": last24_idx, "residual": residuals.values})
        res_chart = alt.Chart(res_df).mark_line(color='#555').encode(x='time:T', y=alt.Y('residual:Q', title='Residual (Actual - Pred)'))
        zero_rule = alt.Chart(pd.DataFrame({"y": [0]})).mark_rule(color='red').encode(y='y:Q')
        st.altair_chart(res_chart + zero_rule, use_container_width=True)
        mae = float(np.mean(np.abs(residuals.values)))
        rmse = float(np.sqrt(np.mean(residuals.values**2)))
        cols = st.columns(2)
        cols[0].metric("MAE (demo backtest)", f"{mae:.4f}")
        cols[1].metric("RMSE (demo backtest)", f"{rmse:.4f}")
    else:
        st.caption("Not enough predicted points to compute residuals.")

with tabs[1]:
    st.header("Drift & Monitoring Status")
    dashboard = load_drift_dashboard()
    if dashboard:
        st.metric("Drift?", "Yes ✅" if dashboard.get("drift_detected") else "No ❌")
        st.metric("Drift Score", f"{dashboard.get('drift_score', 0):.3f}")
        st.write("**Recommendation:**", dashboard.get("recommendation", "-"))
        st.caption(f"Reference samples: {dashboard.get('reference_samples')}")
    else:
        st.warning("No dashboard data found. Run scripts/run_drift_check.py or refresh.")
    if "retr_train" not in st.session_state:
        st.session_state["retr_train"] = False
    retrain = st.button("Trigger Model Retraining", disabled=st.session_state["retr_train"], key="retrain-btn")
    if retrain:
        st.session_state["retr_train"] = True
        with st.spinner("Triggering retraining via API..."):
            resp = call_api("/retrain", method="post", json={})
        if resp and resp.get("success"):
            st.success(f"Retraining started! New model: {resp.get('new_model_name')} (MAE: {resp.get('metrics', {}).get('mae', '?')})")
        else:
            st.error(f"Retrain API call failed: {resp}")
        st.session_state["retr_train"] = False

with tabs[2]:
    st.header("Assistant Chat (Beta)")
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []
    with st.form("assistant-chat-form", clear_on_submit=True):
        q = st.text_area("Ask about your energy trend, anomalies, or ML monitoring:")
        submitted = st.form_submit_button("Send")
    if submitted and q.strip():
        with st.spinner("Contacting assistant..."):
            res = call_api("/assistant", method="post", json={"question": q, "model_name": "groq", "context": {}})
            answer = res.get("answer") if isinstance(res, dict) else str(res)
            details = res.get("details") if isinstance(res, dict) else {}
            if details is None:
                details = {}
            st.session_state.chat_history.append((q, answer, details))
    for idx, (q, a, details) in enumerate(st.session_state.chat_history[::-1]):
        st.markdown(f"**You:** {q}")
        if a:
            st.success(f"**Assistant:** {a}")
            st.code(a, language="markdown")
        else:
            st.error("No answer returned from LLM assistant.")
        context = details.get("context_used") if isinstance(details, dict) else None
        if context:
            st.caption(f"Context: {context}")
        if isinstance(details, dict) and details.get("openai_response"):
            st.expander("Show raw LLM API response").write(details["openai_response"])
    st.caption("Powered by your backend's LLM API and monitoring data.")

with tabs[3]:
    st.header("Reports – Generate and Download")

    reports_dir = Path("reports")
    reports_dir.mkdir(parents=True, exist_ok=True)

    def latest_file(pattern: str):
        files = sorted(glob.glob(pattern), key=lambda p: Path(p).stat().st_mtime, reverse=True)
        return files[0] if files else None

    colA, colB = st.columns(2)
    with colA:
        st.subheader("Drift Report")
        if st.button("Generate Drift Report"):
            with st.spinner("Running drift detection script..."):
                try:
                    proc = subprocess.run(["python", "scripts/run_drift_check.py"], capture_output=True, text=True, timeout=180)
                    if proc.returncode == 0:
                        st.success("Drift check completed. See latest report below.")
                        st.text_area("Log (tail)", proc.stdout[-2000:], height=150)
                    else:
                        st.error("Drift check failed.")
                        st.text_area("Error Log (tail)", (proc.stdout + "\n" + proc.stderr)[-2000:], height=200)
                except Exception as ex:
                    st.error(f"Failed to run drift check: {ex}")
        latest_drift = latest_file(str(reports_dir / "drift_report_*.json"))
        if latest_drift and Path(latest_drift).exists():
            st.caption(f"Latest: {Path(latest_drift).name}")
            with open(latest_drift, "rb") as f:
                st.download_button("Download Drift Report (JSON)", f, file_name=Path(latest_drift).name, mime="application/json")
        else:
            st.caption("No drift report found yet.")

    with colB:
        st.subheader("Evaluation Report")
        if st.button("Generate Evaluation Report"):
            with st.spinner("Running evaluation (test system) script..."):
                try:
                    proc = subprocess.run(["python", "scripts/test_system.py"], capture_output=True, text=True, timeout=300)
                    if proc.returncode == 0:
                        st.success("Evaluation completed. See latest report below.")
                        st.text_area("Log (tail)", proc.stdout[-2000:], height=150)
                    else:
                        st.error("Evaluation script failed.")
                        st.text_area("Error Log (tail)", (proc.stdout + "\n" + proc.stderr)[-2000:], height=200)
                except Exception as ex:
                    st.error(f"Failed to run evaluation: {ex}")
        latest_eval = latest_file(str(reports_dir / "model_evaluation_report_*.md")) or latest_file(str(reports_dir / "system_test_report_*.md"))
        if latest_eval and Path(latest_eval).exists():
            st.caption(f"Latest: {Path(latest_eval).name}")
            with open(latest_eval, "rb") as f:
                st.download_button("Download Evaluation Report (MD)", f, file_name=Path(latest_eval).name, mime="text/markdown")
        else:
            st.caption("No evaluation report found yet.")

    st.divider()
    st.subheader("Monitoring Dashboard Artifact")
    dash_file = Path("reports") / "dashboard" / "dashboard.json"
    if dash_file.exists():
        with open(dash_file, "rb") as f:
            st.download_button("Download Dashboard JSON", f, file_name="dashboard.json", mime="application/json")
        st.caption(f"Updated: {datetime.fromtimestamp(dash_file.stat().st_mtime).isoformat(timespec='seconds')}")
    else:
        st.caption("No dashboard JSON artifact found yet. Run a drift check first.")
